package com.edupablo.parcial1.fabrica_galton;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabricaGaltonApplicationTests {

	@Test
	void contextLoads() {
	}

}
