package com.edupablo.parcial2.fabrica_galton;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import com.edupablo.parcial2.fabrica_galton.abstract_factory.*;
import com.edupablo.parcial2.fabrica_galton.ui.*;

@SpringBootApplication
public class FabricaGaltonApplication {

    private static final Logger logger = LoggerFactory.getLogger(FabricaGaltonApplication.class);

    public static void main(String[] args) {
        try {
            ApplicationContext context = org.springframework.boot.SpringApplication.run(FabricaGaltonApplication.class, args);

            GaltonUI galtonUI = new GaltonUI();

            List<String> datos = cargarDatosDesdeCSV("src/main/resources/dataset.csv");

            ThreadManager threadManager = new ThreadManager(10, datos, 15, galtonUI);
            threadManager.iniciar();
        } catch (Exception e) {
            logger.error("Error en la ejecución de la aplicación", e);
        }
    }

    private static List<String> cargarDatosDesdeCSV(String archivoCSV) {
        List<String> datos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                datos.add(linea);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datos;
    }
}
