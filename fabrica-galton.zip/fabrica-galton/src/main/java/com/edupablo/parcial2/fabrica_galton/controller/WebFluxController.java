package com.edupablo.parcial2.fabrica_galton.controller;

import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.util.List;

@RestController
@RequestMapping("/api")
public class WebFluxController {

    private final List<String> items;

    public WebFluxController(List<String> items) {
        this.items = items;
    }

    @GetMapping("/items")
    public Flux<String> getItems() {
        return Flux.fromIterable(items);
    }
}
