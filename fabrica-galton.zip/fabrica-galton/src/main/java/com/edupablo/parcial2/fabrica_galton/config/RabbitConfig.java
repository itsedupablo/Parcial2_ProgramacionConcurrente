/*
package com.edupablo.parcial2.fabrica_galton.config;


import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {
	
    // Configuración del RabbitTemplate con conexión en cache
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setExchange("my.exchange");
        rabbitTemplate.setRoutingKey("my.routing.key");
        return rabbitTemplate;
    }

    // Configuración de la cola de mensajes
    @Bean
    public Queue myQueue() {
        return new Queue("my.queue", true); // Cola persistente
    }

    // Configuración de Exchange directo
    @Bean
    public DirectExchange directExchange() {
        return new DirectExchange("my.exchange");
    }

    // Configuración de Binding entre la cola y el exchange
    @Bean
    public Binding binding(Queue myQueue, DirectExchange directExchange) {
        return BindingBuilder.bind(myQueue).to(directExchange).with("my.routing.key");
    }

    // Configuración de la conexión cacheada para RabbitMQ
    @Bean
    public ConnectionFactory connectionFactory() {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory("localhost");
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        
        // Limitar el número de conexiones mediante CacheMode
        connectionFactory.setCacheMode(CachingConnectionFactory.CacheMode.CONNECTION);
        connectionFactory.setChannelCacheSize(25);  // Limitar el número de canales por conexión

        // Mantener una sola conexión por defecto (esto limita las conexiones)
        connectionFactory.setConnectionCacheSize(10);  // Establecer tamaño del caché de conexiones (máximo 10 conexiones)

        return connectionFactory;
    }
}

*/
