package com.edupablo.parcial2.fabrica_galton.abstract_factory;

public class ThreadFactory implements ThreadFactoryIFace {

	public ThreadFactory(String tipoHilo) {
	}

	@Override
	public Thread newThread(Runnable runnable) {
		Thread thread = new Thread(runnable);
		return thread;
	}
}
