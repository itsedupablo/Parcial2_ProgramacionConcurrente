package com.edupablo.parcial2.fabrica_galton.ui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GaltonUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel panelGrafica;
    private final List<Columna> columnas;  // Lista de columnas donde las bolas se apilan
    private final int numColumnas = 25;  // Número de "contenedores" o columnas donde las bolas caen
    private final int maxAltura = 1000;  // Altura máxima de la pantalla donde las bolas caen
    private final int offset = 10;  // Ajuste para bajar el gráfico

    public GaltonUI() {
        setTitle("Simulación Máquina de Galton - Distribución Gaussiana");
        setSize(500, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panelGrafica = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                dibujarCuadricula(g);  // Dibuja la cuadrícula de fondo

                // Dibujar las bolas de cada columna
                for (Columna columna : columnas) {
                    columna.dibujarBolas(g);  // Dibuja todas las bolas apiladas en la columna
                }
            }
        };

        panelGrafica.setPreferredSize(new Dimension(800, 500));
        add(panelGrafica, BorderLayout.CENTER);

        columnas = new ArrayList<>();
        // Inicializamos las columnas
        for (int i = 0; i < numColumnas; i++) {
            columnas.add(new Columna(i * (800 / numColumnas), maxAltura - offset));  // Cada columna tiene una posición horizontal
        }

        setVisible(true);
    }

    // Método para actualizar la gráfica con los datos que caen en las columnas
    public void actualizarGrafica(String item) {
        Bola bola = new Bola(400, offset);  // Crear la bola en el centro, pero un poco abajo para que no empiece desde el borde superior

        // Ejecutar un hilo para mover la bola hacia abajo
        new Thread(() -> {
            while (bola.getY() < maxAltura - 50) {  // Ajustamos para que no sobrepase el panel
                bola.mover();  // Mover la bola hacia abajo
                panelGrafica.repaint();  // Redibuja el gráfico cada vez que la bola se mueve
                try {
                    Thread.sleep(50);  // Espera un poco para simular la animación
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            // Cuando la bola llega a la parte inferior, se añade a la columna correspondiente
            int columnaIndex = bola.getColumna();  // Obtener la columna en la que caerá la bola
            columnas.get(columnaIndex).apilarBola(bola);  // Apilar la bola en esa columna
        }).start();
    }

    // Dibuja la cuadrícula de fondo para hacer más claro el gráfico
    private void dibujarCuadricula(Graphics g) {
        g.setColor(Color.LIGHT_GRAY);
        int ancho = panelGrafica.getWidth();
        int alto = panelGrafica.getHeight();

        // Dibujar líneas horizontales
        for (int i = 0; i <= 10; i++) {
            int y = i * alto / 10 + offset;
            g.drawLine(0, y, ancho, y);
        }

        // Dibujar líneas verticales para representar las "columnas"
        for (int i = 0; i <= numColumnas; i++) {
            int x = i * ancho / numColumnas;
            g.drawLine(x, 0 + offset, x, alto + offset);
        }
    }
}
