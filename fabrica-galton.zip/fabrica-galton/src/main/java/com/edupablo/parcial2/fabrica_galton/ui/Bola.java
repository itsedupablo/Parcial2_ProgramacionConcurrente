package com.edupablo.parcial2.fabrica_galton.ui;

import java.awt.*;

public class Bola {
    private int x, y;  // Posición de la bola
    private int radio = 6;  // Reducimos el tamaño de la bola
    private final int anchoPanel = 800;  // Ancho del panel
    
    public Bola(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Método para mover la bola (simulando su caída)
    public void mover() {
        y += 5;  // La bola cae hacia abajo

        // Simula la caída aleatoria de la bola hacia la izquierda o derecha
        if (Math.random() > 0.5) {
            x += 10;  // Se mueve a la derecha
        } else {
            x -= 10;  // Se mueve a la izquierda
        }

        // Limitar la posición de la bola dentro de las columnas
        if (x < 0) x = 0;
        if (x > anchoPanel - radio * 2) x = anchoPanel - radio * 2;
    }

    // Método para dibujar la bola
    public void dibujar(Graphics g, int xPos, int yPos) {
        g.setColor(Color.RED);  // Color de la bola
        g.fillOval(xPos, yPos, radio * 2, radio * 2);  // Dibujamos la bola
    }

    // Métodos para obtener la posición de la bola
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    // Método para obtener el índice de la columna donde caerá la bola
    public int getColumna() {
        return (int) ((x / (double) anchoPanel) * 25);  // Obtener la columna en base a la posición x
    }
}
