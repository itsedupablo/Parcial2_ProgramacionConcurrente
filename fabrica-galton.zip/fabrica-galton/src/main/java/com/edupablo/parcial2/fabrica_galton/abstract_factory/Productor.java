package com.edupablo.parcial2.fabrica_galton.abstract_factory;

import java.util.List;
import java.util.concurrent.BlockingQueue;

import com.edupablo.parcial2.fabrica_galton.ui.GaltonUI;

public class Productor implements Runnable {

    private final List<String> items;
    private final String nombre;
    private final BlockingQueue<String> queue;
    private final int tiempoEspera;
    private final GaltonUI galtonUI;

    public Productor(List<String> items, String nombre, BlockingQueue<String> queue, int tiempoEspera, GaltonUI galtonUI) {
        this.items = items;
        this.nombre = nombre;
        this.queue = queue;
        this.tiempoEspera = tiempoEspera;
        this.galtonUI = galtonUI;
    }

    @Override
    public void run() {
        for (String item : items) {
            try {
                queue.put(item); // Colocar el elemento en la cola
                galtonUI.actualizarGrafica(item);
                System.out.println(nombre + " produjo: " + item);
                Thread.sleep(tiempoEspera); // Simular tiempo de producción
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error en productor " + nombre);
            }
        }
    }
}
