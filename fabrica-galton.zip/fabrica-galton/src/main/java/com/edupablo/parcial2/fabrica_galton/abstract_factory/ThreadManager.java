package com.edupablo.parcial2.fabrica_galton.abstract_factory;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import com.edupablo.parcial2.fabrica_galton.ui.GaltonUI;

public class ThreadManager {
    private final int numHilos;
    private final List<String> items;
    private final int tiempoEspera;
    private final GaltonUI galtonUI;

    public ThreadManager(int numHilos, List<String> items, int tiempoEspera, GaltonUI galtonUI) {
        this.numHilos = numHilos;
        this.items = items;
        this.tiempoEspera = tiempoEspera;
        this.galtonUI = galtonUI;
    }

    public void iniciar() {
        // Crear la cola compartida
        BlockingQueue<String> queue = new LinkedBlockingQueue<>(items.size());

        // Crear fábricas de hilos para productores y consumidores
        ThreadFactoryIFace productorFactory = new ThreadFactory("Productor");
        ThreadFactoryIFace consumidorFactory = new ThreadFactory("Consumidor");

        // Crear y ejecutar productores
        for (int i = 0; i < numHilos / 2; i++) {
            List<String> sublist = items.subList(i * items.size() / (numHilos / 2),
                    (i + 1) * items.size() / (numHilos / 2));
            Runnable productor = new Productor(sublist, "Productor[" + i + "]", queue, tiempoEspera, galtonUI);
            Thread thread = productorFactory.newThread(productor);
            thread.setName("Hilo Productor: " + i); // Asignar el nombre aquí
            thread.start();
        }

        // Crear y ejecutar consumidores
        for (int i = 0; i < numHilos / 2; i++) {
            Runnable consumidor = new Consumidor("Consumidor[" + i + "]", queue, tiempoEspera);
            Thread thread = consumidorFactory.newThread(consumidor);
            thread.setName("Hilo Consumidor: " + i); // Asignar el nombre aquí
            thread.start();
        }
    }

}
