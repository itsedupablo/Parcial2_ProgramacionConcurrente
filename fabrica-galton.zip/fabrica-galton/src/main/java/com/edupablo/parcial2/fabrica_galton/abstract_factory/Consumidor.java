package com.edupablo.parcial2.fabrica_galton.abstract_factory;

import java.util.concurrent.BlockingQueue;

public class Consumidor implements Runnable {

    private final String nombre;
    private final BlockingQueue<String> queue;
    private final int tiempoEspera;

    public Consumidor(String nombre, BlockingQueue<String> queue, int tiempoEspera) {
        this.nombre = nombre;
        this.queue = queue;
        this.tiempoEspera = tiempoEspera;
    }

    @Override
    public void run() {
        while (true) {
            try {
                String item = queue.take(); // Extraer un elemento de la cola
                System.out.println(nombre + " consumió: " + item);
                Thread.sleep(tiempoEspera); // Simular tiempo de consumo
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error en consumidor " + nombre);
                break;
            }
        }
    }
}
