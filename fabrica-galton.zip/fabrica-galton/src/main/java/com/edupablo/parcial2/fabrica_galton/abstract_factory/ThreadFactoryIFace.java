package com.edupablo.parcial2.fabrica_galton.abstract_factory;

public interface ThreadFactoryIFace {
    // Método para crear un nuevo hilo
    Thread newThread(Runnable runnable);
}

