package com.edupablo.parcial2.fabrica_galton.ui;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Columna {
    private final int x;  // Posición horizontal de la columna
    private final int maxAltura;  // Altura máxima para la caída de bolas
    private final List<Bola> bolas;  // Lista de bolas que caen en esta columna

    public Columna(int x, int maxAltura) {
        this.x = x;
        this.maxAltura = maxAltura;
        this.bolas = new ArrayList<>();
    }

    // Añadir una bola a la columna (simulando el apilamiento)
    public void apilarBola(Bola bola) {
        bolas.add(bola);
    }

    // Método para dibujar las bolas apiladas en esta columna
    public void dibujarBolas(Graphics g) {
        for (int i = 0; i < bolas.size(); i++) {
            Bola bola = bolas.get(i);
            bola.dibujar(g, x, maxAltura - (i * 15));  // Dibujar bola en la posición de apilamiento
        }
    }
}
